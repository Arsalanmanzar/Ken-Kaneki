![Bestie](https://siasky.net/jADjITG97ri_AW1KpKwUgVLuI6SqfP6NY5KTd1rso1Rsvg)
# Bestie Robot

<b>A Modular Bestie Telegram Python Group Management Bot Running On Python3 With An Elephant Sqlalchemy, Redis, Mongodb database.</b>

### ╒═══「 Creator Info/Credits 」

+ ➢ [MaddieTheRock](https://github.com/MaddieTheRock) <b>: 2nd OWNER | DEV | Noob</b>
+ ➢ [Aasf](https://github.com/AASFCYBERKING) <b>: REPO | 1st OWNER | Sensei | BFF</b>

╘══「 <b>Any Other Authorship/Credits Can Be Seen Through The Commits.<b> 」

[![forthebadge made-with-python](http://ForTheBadge.com/images/badges/made-with-python.svg)](https://www.python.org/)

The Support Group Can Be Reached Out To At [@MaddieTheRock](https://t.me/MaddieTheRock), Where You Can Ask For Help About [Bestie Robot ](https://t.me/Bestie_Robot), Discover/Request New Features, Report Bugs, And Stay In The Loop Whenever A New Update Is Available. 
